local TRAIT_ICON = {
    ['ambitious'] = 'mountaintop.png',
    ['content'] = 'inner-self.png',
    ['loyal'] = 'check-mark.png',
    ['greedy'] = 'receive-money.png',
    ['warlike'] = 'barbute.png',
    ['bad organiser'] = 'shrug.png',
    ['good organiser'] = 'pitchfork.png',
    ['lazy'] = 'parmecia.png',
    ['hard worker'] = 'miner.png',
    ['trader'] = 'scales.png',
}

return TRAIT_ICON