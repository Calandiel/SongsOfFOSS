---@enum JOBTYPE
local JOBTYPE = {
    FORAGER = 1,
    FARMER = 2,
    LABOURER = 3,
    ARTISAN = 4,
    CLERK = 5,
    WARRIOR = 6,
    HAULING = 7
}

return JOBTYPE