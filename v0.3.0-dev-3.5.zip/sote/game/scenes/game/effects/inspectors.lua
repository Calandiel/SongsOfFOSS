local effects = {}


-- function effects.select_inspector(gam, inspector, data)

-- end