./sote/engine/bins/linux/love.AppImage sote
