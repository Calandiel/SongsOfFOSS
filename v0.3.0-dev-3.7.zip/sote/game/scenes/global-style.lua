UI_STYLE = {
    scrollable_list_thin_item_height = 15,
    scrollable_list_small_item_height = 20,
    scrollable_list_item_height = 25,
    scrollable_list_large_item_height = 30,
    scrollable_list_widget_item_height = 50,
    slider_width = 20,
    square_button_large = 40,
    table_header_height = 20
}