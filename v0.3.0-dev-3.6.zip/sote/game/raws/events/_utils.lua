local Event = require "game.raws.events"

local utils = {}

---comment
---@param name string
---@param text fun(self:Event, root:Character, associated_data:table|nil):string
---@param option_name fun(root:Character, associated_data:table|nil):string
---@param tooltip fun(root:Character, associated_data:table|nil):string
---@param effect fun(root:Character, associated_data:table|nil)?
function utils.notification_event(name, text, option_name, tooltip, effect)
	Event:new {
		name = name,
		event_text = text,
		event_background_path = "data/gfx/backgrounds/background.png",
		automatic = false,
		base_probability = 0,
		trigger = function(self, character)
			return false
		end,
		on_trigger = function(self, character, associated_data)
		end,
		options = function(self, character, associated_data)
			return {
				{
					text = option_name(character, associated_data),
					tooltip = tooltip(character, associated_data),
					viable = function() return true end,
					outcome = function()
						if effect ~= nil then
							effect(character, associated_data)
						end
					end,
					ai_preference = function ()
						return 1
					end
				}
			}
		end
	}
end

utils.dead_options = {{
	text = "I am dead, there is nothing i could do.",
	tooltip = "",
	viable = function() return true end,
	outcome = function () end,
	ai_preference = function() return 1 end
}}

return utils