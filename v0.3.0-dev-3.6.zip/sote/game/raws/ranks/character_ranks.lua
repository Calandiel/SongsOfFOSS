
---@enum CHARACTER_RANK
local ranks = {
    NOBLE = 1,
    CHIEF = 2,
}



return ranks