local tabb = require "engine.table"

local mi = {}

---@param realm Realm
function mi.run(realm)
	-- place military related AI here.
end

return mi
