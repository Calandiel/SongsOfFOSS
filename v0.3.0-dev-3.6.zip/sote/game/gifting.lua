local consts = {}

consts.gift_cost_per_pop = 1

return consts
