return {
	"Every province has a local government. Even an old coreland may at some point raise against you. Keep tabs on your subjects and don't expect them to fall in line easily.",
	"Technologies are researched and forgotten based on your research level. Keep it over 100% to avoid loss of technology.",
	"Races differ in lifespan, productivity and ethics. While an elven chieftan may rely on voluntary community contributions, a goblin society may be forced to extract value through more direct means.",
	"Foraging yield depends on temperature, rainfall, local vegetation, biome, soil conditions and more. Consult building efficiency map modes to get a human-readable summary."
}
