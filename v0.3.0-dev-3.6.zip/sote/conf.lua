

function love.conf(t)
	t.console = true

	--t.window.title = "Songs of the Eons"
	--t.window.fullscreentype = "desktop"
end